int InsertionSort(int A[], int size)
{
    int n = A.size();
    for (int i = 1; i < n; i++)
    {
        int valueToInsert = A[i];
        int prevIndex = i - 1;

        while (prevIndex >= 0 && valueToInsert < A[prevIndex])
        {
            A[prevIndex + 1] = A[prevIndex];
            prevIndex--;
        }

        A[prevIndex + 1] = valueToInsert;
    }
    return A;
}
