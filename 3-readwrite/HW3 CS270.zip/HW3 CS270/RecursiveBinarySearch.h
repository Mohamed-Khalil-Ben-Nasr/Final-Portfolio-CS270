int RecursiveBinarySearch(int arr[], int low, int high, int x)
{
    if (low > high)
        return false;
    else
    {
        // if the array has one element
        if (low == high)
        {
            if (arr[low] == x)
                return low;
            else
                return -1;
        }
        // if the array has multiple elements
        else
        {
            int mid = (low + high) / 2;
            if (arr[mid] == x)
                return mid;
            else if (x > mid)
                RecursiveBinarySearch(arr, mid + 1, high, x);
            else
                RecursiveBinarySearch(arr, low, mid - 1, x);
        }
    }
}

/*The connections that I am seeing between the linear and recursive versions of binary search are that both of them operate in
the same time complexity of O(log(n)) and both utilize the divide and conquer method*/