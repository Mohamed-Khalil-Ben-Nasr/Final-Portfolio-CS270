
#ifndef BINARYSEARCHTREE_H_ // "header guards"
#define BINARYSEARCHTREE_H_ // prevents double inclusion

#include <iostream>

template <class T>
class BST
{
    struct Node
    {
        T _x;
        Node *_parent;
        Node *_left;
        Node *_right;
    };
    int _n;
    Node _root;

public:
    // constructor
    BST();

    BST(T x);

    // destructor
    ~BST();

    // is x in the tree?
    bool isElement(T x);

    void showNode(T x);

    bool add(T x);

    void dfsTraversal(Node *currentNode);

    // I thought remove function should also be a boolean
    bool remove(T x);

    int size();
};

template <class T>
BST<T>::BST()
{
    _n = 0;
}

template <class T>
BST<T>::BST(T x)
{
    _n = 0;
    _root.x = x;
    _root._parent = nullptr;
    _root._left = nullptr;
    _root._right = nullptr;
}

template <class T>
BST<T>::~BST() {}

template <class T>
bool BST<T>::isElement(T x)
{
    Node *currentNode = &_root;
    while (currentNode != nullptr)
    {
        if (x < currentNode->_x)
        {
            currentNode = currentNode->_left;
        }
        else if (x > currentNode->x)
        {
            currentNode = currentNode->_right;
        }
        else
        {
            return true;
        }
    }
    return false;
}

template <class T>
void BST<T>::showNode(T x)
{
    if (!isElement)
    {
        std::cout << "Such node doesn't exist" << std::endl;
        return;
    }
    else
    {
        while (currentNode != nullptr)
        {
            if (x < currentNode->_x)
            {
                currentNode = currentNode->_left;
            }
            else if (x > currentNode->x)
            {
                currentNode = currentNode->_right;
            }
            else
            {
                break;
            }
        }
        std::cout << currentNode->_parent << std::endl;
        std::cout << currentNode->_left << std::endl;
        std::cout << currentNode->_right << std::endl;
    }
}

template <class T>
bool BST<T>::add(T x)
{
    // if tree is empty,
    if (_root == nullptr)
    {
        // create a new node to be the root and define its members.
        _root = new Node;
        _root->_x = x;
        _root->parent = nullptr;
        _root->_left = nullptr;
        _root->_right = nullptr;
        _n++;
        return true;
    }

    // starts from the root node
    Node *currentNode = _root;
    Node *parentNode = nullptr;
    // repeat until current becomes null
    while (currentNode != nullptr)
    {
        if (x < currentNode->_x)
        {
            parentNode = currentNode;
            currentNode = currentNode->_left;
        }
        else if (x > currentNode->_x)
        {
            parentNode = currentNode;
            currentNode = currentNode->_right;
        }
        else
        {
            // x == _x
            return false;
        }
    }
    // now we create a new node on the null spot we landed
    // link it to the parent
    Node *newNode = new Node;
    newNode->_x = x;
    newNode->_parent = parentNode;
    newNode->_left = nullptr;
    newNode->_right = nullptr;

    if (x < parentNode->_x)
    {
        parentNode->_left = newNode;
    }
    else
    {
        parentNode->_right = newNode;
    }

    _n++;
    return true;
}

template <class T>
bool BST<T>::remove(T x)
{
    Node *currentNode = _root;
    Node *parentNode = nullptr while (currentNode != nullptr && currentNode->_x != x)
    {
        parentNode = currentNode;
        if (x < currentNode->_x)
        {
            currentNode = currentNode->_left;
        }
        else
        {
            currentNode = currentNode->_right;
        }
    }

    if (currentNode == nullptr)
    {
        // Node with value x is not found
        return false;
    }

    // 3 Cases

    // the node to remove has no children / is a leaf node
    if (currentNode->_left == nullptr && currentNode->_right == nullptr)
    {
        if (parentNode == nullptr)
        {
            _root = nullptr;
        }
        else if (currentNode == parentNode->_left)
        {
            parentNode->_left = nullptr;
        }
        else
        {
            parentNode->_right = nullptr;
        }
        delete currentNode;
    }
    // has one child
    else if (currentNode->_left == nullptr)
    {
        // node to remove has a right child
        if (parentNode == nullptr)
        {
            // node to remove is the root
            _root = currentNode->_right;
        }
        else if (currentNode == parentNode->_left)
        {
            // node to remove is left of the parent
            // connect parent with the current's right child
            parentNode->_left = currentNode->_right;
        }
        else
        {
            // same but it's the right side
            parentNode->_right = currentNode->_right;
        }
        currentNode->_right->_parent = parentNode;
        delete currentNode;
    }
    else if (currentNode->_right == nullptr)
    {
        if (parentNode == nullptr)
        {
            // node to remove is the root
            _root = currentNode->_left;
        }
        else if (currentNode == parentNode->_left)
        {
            // node to remove is left of the parent
            // connect parent with the current's left child
            parentNode->_left = currentNode->_left;
        }
        else
        {
            // same but it's the right side
            parentNode->_right = currentNode->_left;
        }
        currentNode->_left->_parent = parentNode;
        delete currentNode;
    }
    // has two children
    else
    {
        Node *successorNode = currentNode->_right;
        while (successorNode->_left != nullptr)
        {
            successorNode = successorNode->_left;
        }

        currentNode->_x = successorNode->_x;

        if (successorNode == successorNode->_parent->_left)
        {
            successorNode->_parent->_left = successorNode->_right;
        }
        else
        {
            successorNode->_parent->_right = successorNode->_right;
        }

        if (successorNode->_right != nullptr)
        {
            successorNode->_right->_parent = successorNode->_parent;
        }

        delete successorNode;
    }

    _n--;
    return true;
}

template <class T>
void BST<T>::dfsTraversal(Node *currentNode)
{
    if (currentNode == NULL)
        return;

    /* first recur on left child */
    dfsTraversal(currentNode->left);

    /* then print the data of node */
    cout << currentNode->data << " ";

    /* now recur on right child */
    dfsTraversal(currentNode->right);
}

template <class T>
int BST<T>::size()
{
    return _n;
}

#endif /*BINARYSEARCHTREE_H_*/