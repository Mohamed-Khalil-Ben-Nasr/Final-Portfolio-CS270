#include <iostream>
#include "BinarySearchTree.h"
// collaborated with Min Jun on this assignment

int main()
{
    BST<int> binaryTree;

    binaryTree.add(50);
    binaryTree.add(17);
    binaryTree.add(72);
    binaryTree.add(12);
    binaryTree.add(23);
    binaryTree.add(54);
    binaryTree.add(76);
    binaryTree.add(9);
    binaryTree.add(14);
    binaryTree.add(19);
    binaryTree.add(67);

    binaryTree.showNode(50);
    binaryTree.dfsTraversal(binaryTree < -_root);
}