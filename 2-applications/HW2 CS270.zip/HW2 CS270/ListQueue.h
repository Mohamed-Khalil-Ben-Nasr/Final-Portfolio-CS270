/*I am going to use a singly linked list for the implementation of a ListQueue. Indeed, a stack only needs to
add from the back and remove elements from the front. A singly linked list can handle the enqueue() and dequeue() operations
efficiently with O(1) time complexity and it is simpler and requires less memory than
a doubly linked list.*/

#include "SLList.h"
#include <iostream>

template <class T>
class ListQueue
{
public:
    ListQueue(){};

private:
    SLList<T> list_;

    void enqueue(T x);
    T dequeue();
}

template <class T>
void ListQueue<T>::enqueue(T x)
{
    add(_n, x);
}

template <class T>
T ListQueue<T>::dequeue()
{
    return remove(0);
}