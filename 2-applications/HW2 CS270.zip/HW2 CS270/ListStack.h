/*I am going to use a singly linked list for the implementation of a ListStack. Indeed, a stack only needs to
add and remove elements from the top. A singly linked list can handle the push() and pop() operations
efficiently with O(1) time complexity and it is simpler and requires less memory than
a doubly linked list.*/

#include "SLList.h"
#include <iostream>

template <class T>
class ListStack
{
public:
    ListStack(){};

private:
    SLList<T> list_;

    void push(T x);
    T pop();
}

template <class T>
void ListStack<T>::push(T x)
{
    add(_n, x);
}

template <class T>
T ListStack<T>::pop()
{
    return remove(_n - 1);
}