/*
1- It would make sense to use a queue implementation to represent the problem computationally because 
we need to implement the (FIFO) or first-in-first-out interface.

2- It would make sense to use a queue implementation to represent the problem computationally because 
we need to implement the (FIFO) or first-in-first-out interface.

3- It would make sense to use a stack implementation to represent the problem computationally because 
we need to implement the (LIFO) or last-in-first-out interface.

4- It would make sense to use a deque implementation to represent the problem computationally because 
we need to be able to add and remove elements from both ends of the array.

5- It would make sense to use a stack implementation to represent the problem computationally because 
we need to implement the (LIFO) or last-in-first-out interface.
*/